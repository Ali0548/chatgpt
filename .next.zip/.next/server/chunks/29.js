"use strict";
exports.id = 29;
exports.ids = [29];
exports.modules = {

/***/ 1029:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const Generator = ()=>{
    const [description, setDescription] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const loaderTheBike = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    const [payload, setPayload] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({
        productName: "",
        productDescription: "",
        numResults: null
    });
    const onChange = (e)=>{
        const { name , value  } = e.target;
        setPayload({
            ...payload,
            [name]: value
        });
        console.log("payload", payload);
    };
    const generateDescription = async (e)=>{
        loaderTheBike.current.style.display = "block";
        e.target.innerHTML = "Generating...";
        e.target.disabled = true;
        e.preventDefault();
        const { productName , productDescription , numResults  } = payload;
        if (productName && productDescription && numResults) {
            const result = await fetch("https://chatgpt.merlinwms.co.uk/chat", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "Access-Control-Allow-Origin": "*"
                },
                body: JSON.stringify(payload)
            });
            const data = await result.json();
            const updatedData = data.data.map((obj)=>{
                const key = Object.keys(obj)[0];
                const newKey = key.substring(0, key.length - 1);
                const value = obj[key];
                return {
                    [newKey]: value
                };
            });
            console.log("updatedData", updatedData);
            loaderTheBike.current.style.display = "none";
            e.target.innerHTML = "Generate Again";
            e.target.disabled = false;
            setDescription(updatedData);
        } else {
            loaderTheBike.current.style.display = "none";
            e.target.innerHTML = "Start";
            e.target.disabled = false;
            alert("Please fill all the fields");
        }
    };
    const copyText = (e)=>{
        const text = e.target.parentElement.parentElement.children[0].innerHTML;
        navigator.clipboard.writeText(text).then(()=>{
            e.target.innerHTML = "Text Copied";
            e.target.classList.remove("btn-primary");
            e.target.classList.add("btn-success");
            setTimeout(()=>{
                e.target.classList.remove("btn-success");
                e.target.classList.add("btn-primary");
                e.target.innerHTML = "Copy Text";
            }, 1000);
        }, (err)=>{
            console.error("Async: Could not copy text: ", err);
        });
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            style: {
                height: "90vh"
            },
            className: "content",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "row",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "col-md-12",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "card card-user",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "card-header",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                    className: "card-title",
                                    children: "Generate Description"
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "card-body",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "row",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-md-5",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                                                                    children: "Product Name"
                                                                })
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                type: "text",
                                                                onChange: onChange,
                                                                name: "productName",
                                                                defaultValue: payload.productName,
                                                                className: "form-control",
                                                                placeholder: ""
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-md-5",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                                                                    children: "Description"
                                                                })
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                type: "text",
                                                                onChange: onChange,
                                                                name: "productDescription",
                                                                defaultValue: payload.productDescription,
                                                                className: "form-control",
                                                                placeholder: ""
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-md-5",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "form-group",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                                                                    children: "No. of Result"
                                                                })
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                type: "number",
                                                                onChange: onChange,
                                                                name: "numResults",
                                                                defaultValue: payload.numResults,
                                                                className: "form-control",
                                                                placeholder: ""
                                                            })
                                                        ]
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "row",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "update mx-3",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                        onClick: generateDescription,
                                                        type: "submit",
                                                        className: "btn btn-primary btn-round",
                                                        children: "Start"
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "update mx-3",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                                        style: {
                                                            display: "none"
                                                        },
                                                        class: "bike",
                                                        ref: loaderTheBike,
                                                        id: "bikeLoader",
                                                        viewBox: "0 0 48 30",
                                                        width: "48px",
                                                        height: "30px",
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
                                                            fill: "none",
                                                            stroke: "currentColor",
                                                            "stroke-linecap": "round",
                                                            "stroke-linejoin": "round",
                                                            "stroke-width": "1",
                                                            children: [
                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
                                                                    transform: "translate(9.5,19)",
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("circle", {
                                                                            class: "bike__tire",
                                                                            r: "9",
                                                                            "stroke-dasharray": "56.549 56.549"
                                                                        }),
                                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
                                                                            class: "bike__spokes-spin",
                                                                            "stroke-dasharray": "31.416 31.416",
                                                                            "stroke-dashoffset": "-23.562",
                                                                            children: [
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("circle", {
                                                                                    class: "bike__spokes",
                                                                                    r: "5"
                                                                                }),
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("circle", {
                                                                                    class: "bike__spokes",
                                                                                    r: "5",
                                                                                    transform: "rotate(180,0,0)"
                                                                                })
                                                                            ]
                                                                        })
                                                                    ]
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
                                                                    transform: "translate(24,19)",
                                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
                                                                        class: "bike__pedals-spin",
                                                                        "stroke-dasharray": "25.133 25.133",
                                                                        "stroke-dashoffset": "-21.991",
                                                                        transform: "rotate(67.5,0,0)",
                                                                        children: [
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("circle", {
                                                                                class: "bike__pedals",
                                                                                r: "4"
                                                                            }),
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("circle", {
                                                                                class: "bike__pedals",
                                                                                r: "4",
                                                                                transform: "rotate(180,0,0)"
                                                                            })
                                                                        ]
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
                                                                    transform: "translate(38.5,19)",
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("circle", {
                                                                            class: "bike__tire",
                                                                            r: "9",
                                                                            "stroke-dasharray": "56.549 56.549"
                                                                        }),
                                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
                                                                            class: "bike__spokes-spin",
                                                                            "stroke-dasharray": "31.416 31.416",
                                                                            "stroke-dashoffset": "-23.562",
                                                                            children: [
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("circle", {
                                                                                    class: "bike__spokes",
                                                                                    r: "5"
                                                                                }),
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("circle", {
                                                                                    class: "bike__spokes",
                                                                                    r: "5",
                                                                                    transform: "rotate(180,0,0)"
                                                                                })
                                                                            ]
                                                                        })
                                                                    ]
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("polyline", {
                                                                    class: "bike__seat",
                                                                    points: "14 3,18 3",
                                                                    "stroke-dasharray": "5 5"
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("polyline", {
                                                                    class: "bike__body",
                                                                    points: "16 3,24 19,9.5 19,18 8,34 7,24 19",
                                                                    "stroke-dasharray": "79 79"
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                                    class: "bike__handlebars",
                                                                    d: "m30,2h6s1,0,1,1-1,1-1,1",
                                                                    "stroke-dasharray": "10 10"
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("polyline", {
                                                                    class: "bike__front",
                                                                    points: "32.5 2,38.5 19",
                                                                    "stroke-dasharray": "19 19"
                                                                })
                                                            ]
                                                        })
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "row",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                                                        className: "mx-3",
                                                        style: {
                                                            fontSize: "large"
                                                        },
                                                        children: "Result"
                                                    })
                                                }),
                                                description.map((item, index)=>{
                                                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "col-md-12",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            className: "form-group",
                                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                className: "form-control",
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                        className: "d-flex justify-content-start",
                                                                        children: item.blogPost
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                        className: "d-flex justify-content-end mt-2",
                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                                            type: "button",
                                                                            onClick: copyText,
                                                                            className: "btn btn-primary",
                                                                            children: "Copy Text"
                                                                        })
                                                                    })
                                                                ]
                                                            })
                                                        })
                                                    }, index);
                                                })
                                            ]
                                        })
                                    ]
                                })
                            })
                        ]
                    })
                })
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Generator);


/***/ })

};
;